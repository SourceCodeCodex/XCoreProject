#include <stdio.h>
#include <stdlib.h>

void printNo(){
	int a = 0;
	for(int i =5; i<10; i++){
		if(i == 6){
			continue;
		}
		else
		a = a*i;
	}
}


