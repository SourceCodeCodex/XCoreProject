#include <stdio.h>
#include <signal.h>

int main () {

   int b = 5;

   LOOP:do {

      if( b == 7) {

         b = b + 1;
         goto LOOP;
      }

      printf("b: %d\n", b);
      b++;

   }while( b < 14 );

   return 0;
}
