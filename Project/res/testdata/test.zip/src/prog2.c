#include <string.h>
#include <time.h>

int print(){

	int c = 10;
	    while (c >=0)
	    {
		 if (c==7)
		 {
		      c--;
		      continue;
		 }
		 printf("%d  ", c);
		 c--;
	    }
	    return 0;

}
