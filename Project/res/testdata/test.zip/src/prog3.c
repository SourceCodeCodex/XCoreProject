#include <time.h>
#include <signal.h>
#include <stdio.h>
int main()
{

   for(int i = 0; i<=8; i++){
	if(i==4){
	   goto print;
	}
   }

   print:
   printf("done");

   return 0;
}


