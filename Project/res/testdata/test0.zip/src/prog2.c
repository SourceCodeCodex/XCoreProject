#include <string.h>
#include <time.h>

union animal{
  int fly;
  int swim;
};

int print(){

	int c = 10;
	    while (c >=0)
	    {
		 if (c==7)
		 {
		      c--;
		      continue;
		 }
		 printf("%d  ", c);
		 c--;
	    }
	    return 0;

}
