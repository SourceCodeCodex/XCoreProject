#include <stdio.h>
#include <time.h>

int main()
{  int i;
   for (int i=0; i<=6; i++)
   {
      if (i==3)
      {
	    continue;
      }
       printf("no: %d ", i);
   }
   return 0;
}
