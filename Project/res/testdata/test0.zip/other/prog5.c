#include <stdio.h>
#include <stdlib.h>
#include <time.h>

union a{
	int x;
	float y;
};
void printNo(int y,...){
	int a = 0;
	for(int i =5; i<10; i++){
		if(i == 6){
			continue;
		}
		else
		a = a*i;
	}
}



