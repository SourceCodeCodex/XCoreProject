
#include <stdio.h>
int main() {

    int number1, d;
    unsigned int number2;

    scanf("%d %d", &number1, &number2);

    // calculating
    d = -(number1 + number2)*2;

    printf("%d", d);
    return 0;
}
