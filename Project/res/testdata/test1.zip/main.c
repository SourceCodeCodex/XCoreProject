#include <stdio.h>
#include <stdlib.h>

struct Person
{
    char name[50];
    unsigned int age:1;
    float salary:5;
};

//main function
int main(){
	struct person a;
	strcpy(a.name,"Ana");
	a.age = 22;
	int sum();
	printf("%d",a.age); //print a
}



