#include <stdio.h>

/*
 * calculate the sum
 */

struct myStruct{
	double x:3;
	signed int f:1;
	signed int:1;
	signed int a:3;
};

int function2(int a, int b){
	return a+b; //sum
} /* end /* of function*/

int negativ(unsigned int a){
	int b;
	b = -a;
	return b;
}

void myFunction(){
	int a = 0,b =3,i,j;
	i = a += 2, a + b;
	printf("%d",i);

	for(i = 0, j = 5; i < 6; i++, j++) {
		printf("%d", i+j);
	}
}
