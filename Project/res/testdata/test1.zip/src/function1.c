/*function1.c /* */

void function();

void function(){
	int i = -10;
	int par(int);

	while(i<0){
		printf("%d",i); /*prints numbers from -10 to -1 */
		i++;
	}
}

int par(int n){
  if(n%2==0)
	  return 1;
  else return 0;
}

int negativSum(unsigned int a, unsigned int b){
	int c = -(a+b);

	return c;
}
