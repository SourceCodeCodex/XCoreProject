
enum color { red = 3, blue, green, yellow = 5 };

int main(){
	int a=2;
	int b = ++a -3;
	int c = 2 * b--;

	do
	printf("%d",c--);
	while(c>0);

	if(c>b)
	  {
	    printf("c");
	  }
	else
	  printf("b");

	if(a>b){
	  printf("c");
	}
}
