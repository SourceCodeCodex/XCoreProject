
enum aEnum{a=3, b,c};
enum bEnum{a, b, c};
int main(){
	int a[];
	extern int b[];
	a[0] = 3;
	a[1] = 4;
	a[2] = 5;

	for(int i=0; i<3 ; i++)
		b[i] = a[i]*2;

	switch(a[2]){
	case 0: {printf("%d",b[0]); break;}
	case 1: {printf("%d",b[1]); break;}
	case 2: {printf("%d",b[2]); break;}
	default: printf("\n");
	}

	return 0;
}


