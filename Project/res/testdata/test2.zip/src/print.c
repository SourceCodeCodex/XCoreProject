#include <stdio.h>
#include <errno.h>
enum flag{constant1, constant2, constant3 = 2 };
enum State {Working = 1, Failed = 0};

void sum(){
	extern int vector[];
	extern float a[3];
	extern int b[] = {1,2,4};
	int i=2;
	while(i>=0)
		vector = a[i] + b[i];

}

void calculate(int number){
	int a,b;
	a = number++;
	b = a * a--;
	if(b==0)
		exit(-1);
	switch(b){
	default: {printf("\n"); break; }
	case 0: {printf("%d",b); break; }
	case 1: {printf("%d",1); break; }
	}
}

int main()
{
    char a[10] = "3.14";
    float pf = atof(a);
    long int pi = atol(a);
    printf("pi = %f %d\n", pf,pi);

    if(pf>3){
      printf("%f",pf);}
    else
      if(pf<3)
	printf("%f",pi);
    if(errno != 0)
      { printf("%d",errno);}
    return 0;
}

