#include <stdio.h>

int sum(char number){
	int a = atoi(number);
	int i=0;
	for(int i=0;i<a;i++)
	{
		i = i+a;
	}
	return 0;
}

void print(int a){

	switch(a)
	case 0:printf(0);
}

int main () {
   FILE *fp;

   printf("Going to open nofile.txt\n");
   fp = fopen( "nofile.txt","r" );
   if(fp == NULL) {
      printf("Going to abort the program\n");
      abort();
   }
   printf("Going to close nofile.txt\n");
   fclose(fp);

   return(0);
}
