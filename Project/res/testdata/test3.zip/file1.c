#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *ptr, i , n1=2, n2=5;

    ptr = (int*) malloc(n1 * sizeof(int));

    ptr = realloc(ptr, n2 * sizeof(int));

    for(i = 0; i < n2; ++i)
         printf("%u\n", ptr + i);

    free(ptr);

    return 0;
}

void test(float x, float y)
{
	if(x==y)
		printf("x==y");
	if(x<=y)
		printf("x<=y");
}

int t()
{
	float a[5]={1.2,1.4,5.6,4.9,6.4};

	for(float i=0; i<4; i++)
	{
		test(a[i],i);
	}

	return 0;
}


