#include<stdio.h>
#include<setjmp.h>
jmp_buf buf;
void func()
{
    printf("Welcome\n");
    longjmp(buf, 2);

    printf("Bye\n");
}

int main()
{
    if (setjmp(buf))
        printf("yy\n");
    else
    {
        printf("nn\n");
        func();
    }
    return 0;
}

void bit()
{signed int i = 3;
printf("%d",i>>2);
int x = i|1;
printf("%d", i^3);
}

int count(long n) {
    unsigned int num = 0;
    if (n)
        do num++; while (n &= n - 1);
    return num;
}
