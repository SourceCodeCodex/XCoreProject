#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

#define a {	int x,y; for (int i = 0; i < 10; i++) {if (x>0) {  break;    } else if (x<0) {   break;         } else { }}}

int fun()
{a;
	int j=2;

	do
	{j++;

	if(j==3)
		break;
	if(j==5)
		break;

	}while(j==10);

	return 0;
}


int main () {
   int v;
   jmp_buf buf;

   v = setjmp(buf);

   if( v != 0 ) {
      exit(0);
   }

   printf("Jump function call\n");
   jmpfunction(buf);

   return(0);
}

void jmpfunction(jmp_buf buf) {
   longjmp(buf, "some");
}
