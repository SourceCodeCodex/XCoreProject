#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

typedef float a;
typedef a b;


int f(int x)
{b y;
for(int i=0;i<y;i++)
{}

	while (x<4) {
	  if (x==2) {
	    break;
	  }
	  if (x==1) {
	    break;
	  }
	}
	return 0;
}


int sum()
{
    int n = 7;
    int i, *ptr, sum = 0;

    ptr = (int*) calloc(n, sizeof(int));
    if(ptr == NULL)
    {
        exit(0);
    }
    for(i = 0; i < n; ++i)
    {
        scanf("%d", ptr + i);
        sum += *(ptr + i);
    }
    free(ptr);
    return sum;
}



