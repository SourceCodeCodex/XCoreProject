
float f(double x, double y)
{
	if(x<y)
		return x;
	else
		return y;
}

int main()
{
	double x=2.3;
	double y=3.4;
	for(int i=0;f(x,y)<y;i++)
	{
		printf("%d",i);
		if(i == 2)
			break;

		if(i == 3)
			break;
		break;
	}
	int j = 0;
	while(j<5)
	{
		printf("%d",j);
		for(int i=j;i<7;i++)
		{
			if(i==2)
				break;
		}
		if(j==3)
			break;
		j++;
	}

}

int count(long n) {
    signed int num = 0;
    for (int i = 0; i < 32; i++)
        if (num & (1 << i)) num++;
    return num;
}

